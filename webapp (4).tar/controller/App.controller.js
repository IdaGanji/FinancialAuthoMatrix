sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/odata/v2/ODataModel",
        "zfiauthomatrix/utils/service",
        "sap/ui/model/json/JSONModel",
        "zfiauthomatrix/utils/errorHandler",
        "sap/m/MessageBox",
        "sap/ui/core/Fragment",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "zfiauthomatrix/utils/formatter",
        "sap/ui/core/format/DateFormat"
    ],
    function(Controller,ODataModel,service,JSONModel,errorHandler,MessageBox,Fragment,Filter,FilterOperator,formatter,DateFormat) {
      "use strict";
  
      return Controller.extend("zfiauthomatrix.controller.App", {
        formatter: formatter,          
        onInit() {
            this.initFilterModel();
            this.setColomnsModel();
            this.getTableData();
            this.getValueHelpEmployeeData();
            this.getValueHelpRolesData();
            this.setNewEmployeeData();

        },
        getTableData:function(){
            service.get("/POAAuthMatrixSet").then(
                function(oData) {
                     this.setJSONModel(oData, "mainModel");
                }.bind(this)).then(undefined,
                function(oError) {
        
                    this.showErrorMessage(oError);
                 
                }.bind(this));	
        },
        getValueHelpEmployeeData:function(){
            service.get("/Z_I_PersonContactDetails").then(
                function(oData) {
                    this.setJSONModel(oData, "employeeData");
                    
                }.bind(this)).then(undefined,
                function(oError) {
        
                    this.showErrorMessage(oError);
                 
                }.bind(this));	
        },
        getValueHelpRolesData:function(){
            service.get("/Z_I_POARole").then(
                function(oData) {
                    this.setJSONModel(oData, "rolesData");
                    
                }.bind(this)).then(undefined,
                function(oError) {
        
                    this.showErrorMessage(oError);
                 
                }.bind(this));	
        },
        setNewEmployeeData:function(){
            var newData = {
				Roleowner: "",
				Role: "",
				Startdate: new Date(),
				Enddate: new Date()
			};
            this.setJSONModel(newData,"newEmployee");

        },
        buildFilter:function(){
            var filterModel = this.getView().getModel("filterModel").getData();

            var Role=filterModel.role;
            var RoleOwner=filterModel.owner;
            var Status = filterModel.status; 
            var arrayFilter = [];

            if (Role) {
                arrayFilter.push(new Filter({
                       path: "Role",
                       operator: FilterOperator.EQ,
                       value1: Role,
                      
               }));
            }

            if (RoleOwner) {
                arrayFilter.push(new Filter({
                       path: "Roleowner",
                       operator: FilterOperator.EQ,
                       value1: RoleOwner,
                      
               }));
            }
            
            if (Status) {
                arrayFilter.push(new Filter({
                       path: "Status",
                       operator: FilterOperator.EQ,
                       value1: Status,
                       
               }));
            }
            
            return arrayFilter;
        },
        initFilterModel:function(){
			var filter={
				role:[],
                owner:[],
                status:""
			};
            var oModel = new JSONModel();
            oModel.setData(filter);
            oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
            return this.getView().setModel(oModel, "filterModel");
			
		},
        setJSONModel: function (oData, sName) {
            var oModel = new JSONModel();
            oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
            oModel.setData(oData);
            return this.getView().setModel(oModel, sName);
        },
        showErrorMessage: function(oError) {
            var errorDetails = errorHandler.parseError(oError);
            
            MessageBox.error(errorDetails.message, {
                icon:		MessageBox.Icon.ERROR,
                 title:		this.geti18nString("error"),
                details:	errorDetails.details,
                actions:	MessageBox.Action.CLOSE
            });
        },
        geti18nString: function(sKey, aArgs) {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sKey, aArgs);
        },
        setColomnsModel:function(){
            var oColumnsR={
               "cols": [
                   {
                       "label": "Role",
                       "template": "Role",
                       "width": "15rem"
                   
                   },
                   {
                       "label": "Role Description",
                       "template": "Roledescription"
                   }
               ]
           };
           this.oColModel = new JSONModel(oColumnsR);
           var oColumnsO={
            "cols": [
                {
                    "label": "User Name",
                    "template": "Roleowner",
                    "width": "15rem"
                
                },
                {
                    "label": "Full Name",
                    "template": "RoleownerName"
                }
            ]
        };
        this.oColumnModel = new JSONModel(oColumnsO);
           },

    onRoleValueHelpRequest: function() {
        var aCols = this.oColModel.getData().cols,
         oModel=this.getView().getModel("mainModel"),
         oMultiInput=this.getView().byId("roleInput");

        this.loadFragment({
            name: "zfiauthomatrix.view.RoleValueHelpDialog"
        }).then(function(oValueHelpDialog) {
            this._RoleValueHelpDialog = oValueHelpDialog;

            this._RoleValueHelpDialog.getTableAsync().then(function (oTable) {
                oTable.setModel(oModel);
                oTable.setModel(this.oColModel, "columns");

                if (oTable.bindRows) {
                    oTable.bindAggregation("rows", "/results");
                }

                if (oTable.bindItems) {
                    oTable.bindAggregation("items", "/results", function () {
                        return new ColumnListItem({
                            cells: aCols.map(function (column) {
                                return new Label({ text: "{" + column.template + "}" });
                            })
                        });
                    });
                }
                this._RoleValueHelpDialog.update();
            }.bind(this));

            this._RoleValueHelpDialog.setTokens(oMultiInput.getTokens());
            this._RoleValueHelpDialog.open();
        }.bind(this));
    },

    onRoleValueHelpOkPress: function (oEvent) {
        var aTokens = oEvent.getParameter("tokens");
        var oModel= this.getView().getModel("filterModel"),
        oData= oModel.getData();
        oData.role=[];
         aTokens.forEach(function(oToken){
            oData.role.push({key:oToken.getKey(),text:oToken.getText()});
    
        });
        oModel.setData(oData);
        
        this._RoleValueHelpDialog.close();
    },
    

    onRoleValueHelpCancelPress: function () {
        this._RoleValueHelpDialog.close();
    },

    onRoleValueHelpAfterClose: function () {
        this._RoleValueHelpDialog.destroy();
    },
    onOwnerValueHelpRequest: function() {
        var aCols = this.oColumnModel.getData().cols,
         oModel=this.getView().getModel("mainModel"),
         oMultiInput=this.getView().byId("ownerSelect");

        this.loadFragment({
            name: "zfiauthomatrix.view.OwnerValueHelpDialog"
        }).then(function(oValueHelpDialog) {
            this._OwnerValueHelpDialog = oValueHelpDialog;

            this._OwnerValueHelpDialog.getTableAsync().then(function (oTable) {
                oTable.setModel(oModel);
                oTable.setModel(this.oColumnModel, "columns");

                if (oTable.bindRows) {
                    oTable.bindAggregation("rows", "/results");
                }

                if (oTable.bindItems) {
                    oTable.bindAggregation("items", "/results", function () {
                        return new ColumnListItem({
                            cells: aCols.map(function (column) {
                                return new Label({ text: "{" + column.template + "}" });
                            })
                        });
                    });
                }
                this._OwnerValueHelpDialog.update();
            }.bind(this));

            this._OwnerValueHelpDialog.setTokens(oMultiInput.getTokens());
            this._OwnerValueHelpDialog.open();
        }.bind(this));
    },

    onOwnerValueHelpOkPress: function (oEvent) {
        var aTokens = oEvent.getParameter("tokens");
        var oModel= this.getView().getModel("filterModel"),
        oData= oModel.getData();
        oData.owner=[];
         aTokens.forEach(function(oToken){
            oData.owner.push({key:oToken.getKey()});
    
        });
        oModel.setData(oData);
        this._OwnerValueHelpDialog.close();
    },
    

    onOwnerValueHelpCancelPress: function () {
        this._OwnerValueHelpDialog.close();
    },

    onOwnerValueHelpAfterClose: function () {
        this._OwnerValueHelpDialog.destroy();
    },
    
    onPressNewRole:function(){
        this.loadFragment({
            name: "zfiauthomatrix.view.addNewEmployeeDialog"
        }).then(function(oValueHelpDialog) {
            this._addEmployeeDialog = oValueHelpDialog;
            this._addEmployeeDialog.open();
        }.bind(this));
        
    },
    onEmployeeDialogClose:function(){
        this._addEmployeeDialog.close();
     },
     onAfterClose:function(){
        this._addEmployeeDialog.destroy();         
     },
     onAddNewEmployee:function(){
        var roleOwner    = this.getView().getModel("newEmployee").getProperty("/Roleowner");
        var validFrom   = this.getView().getModel("newEmployee").getProperty("/Startdate");
        var validTo     = this.getView().getModel("newEmployee").getProperty("/Enddate");
        var role        = this.getView().getModel("newEmployee").getProperty("/Role");
        validFrom = this._parseDate(validFrom);
        validTo = this._parseDate(validTo);

        var dataToSend = {
            role: role,               
            roleOwner: roleOwner,
            dateValidFrom: validFrom,
            dateValidTo: validTo
        };
         // this.setBusy("newEmployeeDialog", true);

       service.post(dataToSend).then(function (oData) {
        // this.setBusy("newEmployeeDialog", false);
       //  this.onEmployeeDialogClose(sFragment);
       //  this.setBusy("mainPageTable", true);
         
       service.get("/POAAuthMatrixSet",{
             expand: "POAAuthHD2MatrixSet"
         }).then(function (data) {
             this.setJSONModel(data, "mainModel");
             //this.setBusy("mainPageTable", false);
         }.bind(this)).then(undefined, function(oError) {
             this.showErrorMessage(oError);
             //this.setBusy("mainPageTable", false);
         }.bind(this));
     
     }.bind(this)).then(undefined, function(oError) {
         this.showErrorMessage(oError);
        // this.setBusy("newEmployeeDialog", false);
     }.bind(this));

 

     },
     _parseDate: function (oDate) {
        var oFormat = DateFormat.getDateInstance({
            pattern: "yyyy-MM-ddTHH:mm:ss"
        });
        return oFormat.format(oDate);
    },
     onEmployeeValueHelp:function(){
        var oView=this.getView();         
        if (!this._employeeDialog) {
            this._employeeDialog = Fragment.load({
                name: "zfiauthomatrix.view.EmployeeValueHelpDialog",
                controller: this
            }).then(function (oDialog){
                oDialog.setModel(oView.getModel("employeeData"),"employeeModel");
                oView.addDependent(oDialog);
                return oDialog;
            });
        };

        this._employeeDialog.then(function(oDialog){
            oDialog.open();
        }.bind(this));
     },
     onSearchEmployeeValueHelp:function(oEvent){
        var sValue = oEvent.getParameter("value");
        var oFilter = new Filter("UserName", FilterOperator.Contains, sValue);
        var oBinding = oEvent.getParameter("itemsBinding");
        oBinding.filter([oFilter]);         
     },
     onEmployeeDialogConfirm:function(oEvent){
        var oSelectedItem = oEvent.getParameter("selectedItem"),
        oInput = this.byId("employeeInput");

    if (!oSelectedItem) {
        oInput.resetProperty("value");
        return;
    }

    oInput.setValue(oSelectedItem.getTitle());

     },     
     onRolesValueHelp:function(){
        var oView=this.getView();         
        if (!this._rolesDialog) {
            this._rolesDialog = Fragment.load({
                name: "zfiauthomatrix.view.RolesValueHelpDialog",
                controller: this
            }).then(function (oDialog){
                oDialog.setModel(oView.getModel("rolesData"),"RolesData");
                oView.addDependent(oDialog);
                return oDialog;
            });
        };

        this._rolesDialog.then(function(oDialog){
           // this.configValueHelpDialog();
            oDialog.open();
        }.bind(this));
     },
     onSearchRoleValueHelp:function(oEvent){
        var sValue = oEvent.getParameter("value");
        var oFilter = new Filter("Role", FilterOperator.Contains, sValue);
        var oBinding = oEvent.getParameter("itemsBinding");
        oBinding.filter([oFilter]);
     },
     configValueHelpDialog: function () {
        var sInputValue = this.byId("productInput").getValue(),
            oModel = this.getView().getModel(),
            aProducts = oModel.getProperty("/ProductCollection");

        aProducts.forEach(function (oProduct) {
            oProduct.selected = (oProduct.Name === sInputValue);
        });
        oModel.setProperty("/ProductCollection", aProducts);
    },
     onRoleDialogConfirm:function(oEvent){
        var oSelectedItem = oEvent.getParameter("selectedItem"),
        oInput = this.byId("rolesInput");

    if (!oSelectedItem) {
        oInput.resetProperty("value");
        return;
    }

    oInput.setValue(oSelectedItem.getTitle());

     },
    onPressEdit:function(){
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("RouteCreateView");
    },
    onSearch:function(oEvent){
        var filterModel = this.getView().getModel("filterModel").getData();
        var oTable = this.getView().byId("idTable");
	    var oBinding = oTable.getBinding("items");
        var Role=filterModel.role;
        var RoleOwner=filterModel.owner;
        var Status = filterModel.status; 
        var arrayFilter = [];
        let roleFilter,
        roleOwnwerFilter;
        let arrayRoleFilter = [],
        arrayRoleOwnerFilter= [];
        if(Role.length>0){
            Role.forEach(function (oItem){
                arrayRoleFilter.push(new Filter({
                         path: 'Role',
                        operator: FilterOperator.EQ,
                         value1: oItem.key
                      }));
            });

            roleFilter= new Filter({
                filters:arrayRoleFilter,
                and: false
                });
                
            arrayFilter.push(roleFilter);

        };
        
        if(RoleOwner.length>0){
            RoleOwner.forEach(function (oItem){
                arrayRoleOwnerFilter.push(new Filter({
                        path: 'Roleowner',
                        operator: FilterOperator.EQ,
                        value1: oItem.key
                      }));
            });

            roleOwnwerFilter= new Filter({
                filters:arrayRoleOwnerFilter,
                and: false
                });
            
            arrayFilter.push(roleOwnwerFilter);

        };
        

        if (Status) {
            arrayFilter.push(new Filter({
                   path: "Status",
                   operator: FilterOperator.EQ,
                   value1: Status,
                   
           }));
        };
    
       oBinding.filter(new Filter({
        filters:arrayFilter,
        and: true
      }));
     },

     onListItemPressed:function(oEvent){
       var oModel= this.getView().getModel("mainModel");
       var oTableModel = this.getOwnerComponent().getModel("TableModel");
    var oData=oModel.getData().results;
    var dataToBePassed=[];
    oData.forEach(function (object){
        if(object.Selected){
            dataToBePassed.push(object);
        };
    });
    oTableModel.setData(dataToBePassed);
    
    
     },
     

    
      });
    }
  );
  