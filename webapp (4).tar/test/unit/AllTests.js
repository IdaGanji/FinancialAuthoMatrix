sap.ui.define([
	"zfiauthomatrix/test/unit/controller/RootView.controller"
], function () {
	"use strict";
});
