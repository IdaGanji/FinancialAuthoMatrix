/* global QUnit */

sap.ui.require(["zfiauthomatrix/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
